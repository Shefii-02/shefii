<?php include "header-inner.php";?>


<!-- PAGE HERO
============================================= -->	
<div id="about-page" class="page-hero-section division">
    <div class="container">	
        <div class="row">	
            <div class="col-lg-10 offset-lg-1">
                <div class="hero-txt text-center white-color">

                    <!-- Breadcrumb -->
                    <div id="breadcrumb">
                        <div class="row">						
                            <div class="col">
                                <div class="breadcrumb-nav">
                                    <nav aria-label="breadcrumb">
                                          <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">About Us</li>
                                          </ol>
                                    </nav>
                                </div>
                            </div>
                        </div> 
                    </div>

                    <!-- Title -->
                    <h2 class="h2-xl">About ChiqBy</h2>

                </div>
            </div>	
        </div>	  <!-- End row -->
    </div>	   <!-- End container --> 
</div>	<!-- END PAGE HERO -->	

</header>
 
<div id="page" class="page"> 




 
<!-- ABOUT-4
============================================= -->
<section id="about-4" class="wide-60 about-section division">
    <div class="container">
        <div class="row ">
            <div class="d-flex align-items-center">

                <div class="col-lg-6">
                    <div class="about-4-txt mb-40">

                        <!-- Title -->	
                        <h2 class="h2-sm">Discover the new taste of the Fried Chicken</h2>
    
                        <!-- Text -->
                        <p class="p-md grey-color">We concentrate all our resources on restaurant operations since that's where we cater to
    our customers. We recognize and appreciate the contributions of every team
    member at Chiqby Foods L.L.P. We continuously enhance and modernise
    our training programs to achieve excellence. We foster an environment
    of openness, honesty, and straightforward communication in all our
    interactions. We uphold the highest standards of personal and
    professional integrity at all times. We promote and embrace new
    and creative ideas, as they are essential for our competitive
    growth. We reward outcomes rather than mere efforts.</p>
     
    
                    </div>
                </div>
                <div class="col-lg-6 mb-40">
                    <img class="img-fluid" src="images/about-us-01.jpg" alt="about-image">
                </div>

            </div>

 
            <div class="d-flex align-items-center">

                <div class="col-lg-6">
                    <img class="img-fluid" src="images/about-us-02.jpg" alt="about-image">
                </div>

                <div class="col-lg-6">
                    <div class="about-4-txt mb-40">

                        <!-- Title -->	
                        <h2 class="h2-sm">OUR VISION</h2>
    
                        <!-- Text -->
                       <p class="p-md grey-color">Our vision is to provide corporate values and operational excellence while consistently maintaining customer satisfaction and achieving business growth and profitability.</p>

                       <h2 class="h2-sm">OUR MISSION</h2>
                       <p class="p-md grey-color">To be the leader in western-style quick-service restaurants through friendly service, good-quality food, and a clean atmosphere.</p>
    
                    </div>
                </div>
                

            </div> 
          

        </div>	   <!-- End row -->
    </div>	   <!-- End container -->
</section>	<!-- END ABOUT-4 --> 

</div>	<!-- END PAGE CONTENT -->


<?php include "footer.php";?>