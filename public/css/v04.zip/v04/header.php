<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
		<meta name="author" content="Jthemes"/>			
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>	 
		<title>Chiqby | The Best Fried Chicken</title> 
		<meta name="description" content="The Best Fried Chicken In the City"/>
		<meta name="keywords" content="good food, bakery, Fried Chicken, cafe, chocolate, coffee, delivery, dessert, donuts, drinks, fast food, organic, restaurant">	
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">  
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">  
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

		<link href="https://use.fontawesome.com/releases/v5.11.0/css/all.css" rel="stylesheet" crossorigin="anonymous">		
		<link href="css/flaticon.css" rel="stylesheet">  
		<link href="css/magnific-popup.css" rel="stylesheet">	
		<!-- <link href="css/flexslider.css" rel="stylesheet">
		<link href="css/owl.carousel.min.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css" rel="stylesheet">  -->
		<link href="css/style.css" rel="stylesheet"> 
		<link href="css/responsive.css" rel="stylesheet">
	
	</head>




	<body> 
		

		<div id="loader-wrapper" >
			<div id="loader">
			<div class="spinner-border" role="status"> 
			  <span class="visually-hidden">Loading...</span> 
			</div>
		</div>
		 </div>
 


			<header class="bg-fixed1">

 
		
		<!-- HEADER-1
		============================================= --> 

		<nav class="navbar navbar-expand-sm sticky-top navbar-sticky" aria-label="">
			<div class="container-fluid ">
			  <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			  </button>
		
			  <div class="navbar-collapse justify-content-md-center collapse" id="navbarsExample08" >
				<ul class="navbar-nav ">
				  
					<li class="nav-item d-flex align-items-center"><a href="index.php" class="nav-link active" aria-current="page">Home</a></li>
					  <li class="nav-item d-flex align-items-center"><a href="about.php" class="nav-link">About</a></li>
					  <li class="nav-item d-flex align-items-center"><a href="franchise.php" class="nav-link">Franchise</a></li>
					  <li class="nav-item d-flex align-items-center"><a href="#" class="nav-link"><img src="images/logo.png" alt="header-logo" style="width: 130px; height: 130px;"/></a></li>					  
					  <li class="nav-item d-flex align-items-center"><a href="menu.php" class="nav-link">Menu</a></li>
					  <li class="nav-item d-flex align-items-center"><a href="gallery.php" class="nav-link">Gallery</a></li>
					  <li class="nav-item d-flex align-items-center"><a href="contact.php" class="nav-link">Contact</a></li>
				  
				</ul>
			  </div>
			</div>
		  </nav>  
		 
	<!-- HERO-2
			============================================= -->	
			<section id="hero-2" class="hero-section division">
				<div class="">	
					<div class="container">							
						<div class="row">
							<div class="col-lg-10 offset-lg-1">
								<div class="hero-2-txt text-center">

									<!-- Title -->
									<h2 class="red-color shadow-txt-white"><span>It's Your</span><br>Fried Choice!</h2>

									<!-- Image -->
									<div class="hero-2-img">
										
										<img class="img-fluid" src="images/home-img.png" alt="hero-image">	

										<!-- Price Badge -->
										<!-- <div class="price-badge-sm bg-fixed white-color1">
											<div class="badge-txt">
												<h5 class="h5-md"></h5>
												<h4 class="h4-lg"></h4>
											</div>
										</div>	 -->

									</div>

								</div>  
							</div>	 
						</div>	 <!-- End row -->
					 


					


				</div>	   <!-- End Bg Inner -->
				<!-- SECTION OVERLAY -->	
				<div class="bg-fixed white-overlay-wave"></div>
			</div>	
			</section>	<!-- END HERO-2 -->	


		</header>