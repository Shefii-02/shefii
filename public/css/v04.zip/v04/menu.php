<?php include "header-inner.php";?>


<!-- PAGE HERO
============================================= -->	
<div id="about-page" class="page-hero-section division">
    <div class="container">	
        <div class="row">	
            <div class="col-lg-10 offset-lg-1">
                <div class="hero-txt text-center white-color">

                    <!-- Breadcrumb -->
                    <div id="breadcrumb">
                        <div class="row">						
                            <div class="col">
                                <div class="breadcrumb-nav">
                                    <nav aria-label="breadcrumb">
                                          <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Menu</li>
                                          </ol>
                                    </nav>
                                </div>
                            </div>
                        </div> 
                    </div>

                    <!-- Title -->
                    <h2 class="h2-xl">Menu</h2>

                </div>
            </div>	
        </div>	  <!-- End row -->
    </div>	   <!-- End container --> 
</div>	<!-- END PAGE HERO -->	

</header>
 
<div id="page" class="page"> 
 
	<!-- MENU-3
			============================================= -->
			<section id="menu-3" class="wide-100 menu-section division">
				<div class="container">


					<!-- MENU-3 WRAPPER -->
			 		<div class="menu-3-wrapper">


			 			<!-- Title -->
			 			<div class="row">
			 				<div class="col-md-12">
					 			<div class="menu-3-title"><h3 class="h3-md red-color">Main Menu</h3></div>
					 		</div>
					 	</div>
					 	


						<div class="row">


							<!-- LEFT COLUMN -->
							<div class="col-lg-6">
								<div class="menu-3-txt">
									<ul class="menu-3-list">

 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CRISPY FRIED
CHICKEN</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">FLAMING HOT
FRIED CHICKEN</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">DESI FRIED
CHICKEN</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">HONEY BBQ
GLAZED FRIED CHICKEN</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">PERI PERI FRIED
CHICKEN</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">Chicken CHIQBY NUGGETS</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">Chicken DESI NUGGETS </h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										
										 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CRISPY CHIQBY STRIPS</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">chicken BONELESS STRIPS</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>  
									</ul>

									<img class="img-fluid mt-35 mb-35" src="images/chiqby-burger.jpg" alt="chiqby-burger">

									<ul class="menu-3-list">
									    <li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">REGULAR BURGER</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>  
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">ZINGER BURGER</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CHEESE BURGER</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">DOUBLE CHEESE BURGER</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">MEGA ZINGER BURGER</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">NUGGETS BURGER</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
									</ul>

									<img class="img-fluid mt-35 mb-35" src="images/chiqby-sauce.jpg" alt="chiqby-sauce">

									<ul class="menu-3-list">
									    <li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">Mayonnaise</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>  
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">PERI PERI SAUCE MIX</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">DYNAMITE SAUCE MIX</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">MEXICAN SAUCE MIX</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">KANTHARI SAUCE MIX</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">Coleslaw</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
									</ul>

								</div>
							</div>	<!-- END LEFT COLUMN -->


							<!-- RIGHT COLUMN -->
							<div class="col-lg-6">
								<div class="menu-3-txt">
									<ul class="menu-3-list">
 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">GRILLS- HONEY BBQ
GLAZED CHICKEN</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">GRILLS- HONEY BBQ
GLAZED CHICKEN</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">GRILLS- HONEY BBQ
GLAZED CHICKEN</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CHIQBY S/P
CHICK POPS</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CHEESE N
JALAPENO POPS</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">MAGIC
MASALA POPS</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CLASSIC
CHICKEN POPS</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CHICKEN 65</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CHICKEN WRAP </h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">ZINGER WRAPS</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">SPICY CHICKEN ROLL</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CRISPY SHAWARMA</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>  
									</ul>

									<img class="img-fluid mt-35 mb-35" src="images/french-fries.jpg" alt="menu-image">

									<ul class="menu-3-list">
 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">REGULAR French Fries</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">MASALA FRIENCH FRIES</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">LOADED FRIES</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">CHEESE JALAPENO FRIES</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">TANDOORI FRIES</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
									</ul>

									<img class="img-fluid mt-35 mb-35" src="images/menu-drinks.jpg" alt="menu-drinks">

									<ul class="menu-3-list">
 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">LEMON MINT MOJITO</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li> 
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">PASSION FRUIT MOJITO</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">STRAWBERRY MOJITO</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">WATERMELON MOJITO</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">BLACKBERRY MOJITO</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">GREEN APPLE MOJITO</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">FRESH LIME MINT</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
										<li class="menu-3-item">
											<a href="javascript:void(0);"> 
												<div class="menu-title-wrapper rel">
													<div class="menu-item-title"><h5 class="h5-sm">PEPSI</h5></div>
													<div class="menu-item-dots"></div>
													<div class="menu-item-price"><i class="fas fa-check-circle"></i></div>													 
												</div> 											
											</a>
										</li>
									</ul>

								</div>
							</div>	<!-- END RIGHT COLUMN -->


						</div>	<!-- End row -->
					</div>	<!-- END MENU-3 WRAPPER --> 

				</div>	   <!-- End container -->
			</section>	<!-- END MENU-3 -->


</div>	<!-- END PAGE CONTENT -->


<?php include "footer.php";?>