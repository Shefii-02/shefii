<?php include "header-inner.php";?>


<!-- PAGE HERO
============================================= -->	
<div id="about-page" class="page-hero-section division">
    <div class="container">	
        <div class="row">	
            <div class="col-lg-10 offset-lg-1">
                <div class="hero-txt text-center white-color">

                    <!-- Breadcrumb -->
                    <div id="breadcrumb">
                        <div class="row">						
                            <div class="col">
                                <div class="breadcrumb-nav">
                                    <nav aria-label="breadcrumb">
                                          <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Contact</li>
                                          </ol>
                                    </nav>
                                </div>
                            </div>
                        </div> 
                    </div>

                    <!-- Title -->
                    <h2 class="h2-xl">Contact</h2>

                </div>
            </div>	
        </div>	  <!-- End row -->
    </div>	   <!-- End container --> 
</div>	<!-- END PAGE HERO -->	

</header>
 
<div id="page" class="page"> 
  
 <!-- CONTACTS-5
			============================================= -->
			<section id="contacts-5" class="wide-80 contacts-section division">	
				<div class="container">


					<!-- CONTACT INFO
					============================================= -->
					<div class="row">
						<div class="col-xl-10 offset-xl-1">
							<div class="row">	


								<!-- LOCATION -->
								<div class="col-md-4">
									<div class="cbox-5">
									
										<!-- Title -->
										<h5 class="h5-lg">Head Office</h5>

										<!-- Address -->
									<p>Chiqby Foods L.L.P</p>  
									<p>P.O Box 32093,</p>  
									<p>Doha-Qatar</p>
									<p>00974-55564876</p>

									</div>
								</div>


								<!-- QUICK CONTACTS -->
								<div class="col-md-4">
									<div class="cbox-5">
									
										<!-- Title -->
									<h5 class="h5-lg">Zonal Office</h5>

<!-- Text -->
<p>Chiqby Foods L.L.P</p>  
<p>Pandikkad Road, Malappuram</p>  
<p>Kerala-676 121</p>
<p>00919747546990</p>

									</div>
								</div>


								<!-- WORKING HOURS -->
								<div class="col-md-4">
									<div class="cbox-5">
									
                                    				
									<!-- Title --> 
										<!-- Title -->	
										<h5 class="h5-lg">Franchise Enquiry</h5>

										<!-- Title -->	
										<p class="p-md">P: +91 974-7546-990</p> 
										<p class="p-md">E: <a href="mailto:info@chiqby.com" class="yellow-color">info@chiqby.com</a></p>

									</div>
								</div>


							</div>
			 			</div>
				 	</div>	<!-- END CONTACT INFO --> 


					<!-- SECTION TITLE -->	
					<div class="row">	
						<div class="col-lg-10 offset-lg-1">
							<div class="section-title mb-40 text-center">	

								<!-- Title 	-->	
								<h2 class="h2-xl">Get in Touch</h2>	

								<!-- Text -->	
								<p class="p-xl">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
									
							</div>	
						</div>
					</div>


					<!-- CONTACT FORM -->	
				 	<div class="row">
				 		<div class="col-lg-10 offset-lg-1">
				 			<div class="form-holder">
								<form name="contactform" class="row contact-form">
																						
									<!-- Form Input -->
					                <div class="col-md-12 col-lg-6">
					                	<input type="text" name="name" class="form-control name" placeholder="Your Name*"> 
					                </div>
					                  
					                <!-- Form Input -->        
					               <div class="col-md-12 col-lg-6">
					                	<input type="email" name="email" class="form-control email" placeholder="Email Address*"> 
					                </div>

					                <!-- Form Input -->   
									<div class="col-md-12">
										<input type="text" name="subject" class="form-control subject" placeholder="What's this about?"> 
									</div>
	
									<!-- Form Textarea -->	        
					                <div class="col-md-12">
					                	<textarea name="message" class="form-control message" rows="6" placeholder="Your Message ..."></textarea>
					                </div> 
					                                            
					                <!-- Form Button -->
					                <div class="col-md-12 mt-5 text-right">  
					                	<button type="submit" class="btn btn-md btn-red tra-red-hover submit">Send Message</button> 
					                </div>
					                                                              
					                <!-- Form Message -->
					                <div class="col-md-12 contact-form-msg text-center">
					                	<div class="sending-msg"><span class="loading"></span></div>
					                </div>	
																							
								</form>	

				 			</div>	
				 		</div>	
				 	</div>  <!-- END CONTACT FORM -->	


				</div>	   <!-- End container -->		
			</section>	<!-- END CONTACTS-5 -->

</div>	<!-- END PAGE CONTENT -->


<?php include "footer.php";?>