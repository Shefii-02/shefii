<?php include "header-inner.php";?>


<!-- PAGE HERO
============================================= -->	
<div id="about-page" class="page-hero-section division">
    <div class="container">	
        <div class="row">	
            <div class="col-lg-10 offset-lg-1">
                <div class="hero-txt text-center white-color">

                    <!-- Breadcrumb -->
                    <div id="breadcrumb">
                        <div class="row">						
                            <div class="col">
                                <div class="breadcrumb-nav">
                                    <nav aria-label="breadcrumb">
                                          <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Gallery</li>
                                          </ol>
                                    </nav>
                                </div>
                            </div>
                        </div> 
                    </div>

                    <!-- Title -->
                    <h2 class="h2-xl">Gallery</h2>

                </div>
            </div>	
        </div>	  <!-- End row -->
    </div>	   <!-- End container --> 
</div>	<!-- END PAGE HERO -->	

</header>
 
<div id="page" class="page"> 
  
<!-- GALLERY-2
			============================================= -->		
			<section id="gallery-2" class="gallery-section division">
				<div class="container">
					<div class="row">


						<!-- IMAGE #1 -->
					  	<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/ISO-9001-2015-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/ISO-9001-2015.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">ISO 9001-2015</h5> 
										</div> 

									</div>
								</a>
							</div>
						</div>

 


						<!-- IMAGE #3 -->
					  	<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-02.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-02.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 										 
										</div> 

									</div>
								</a>
							</div>
						</div>	


						<!-- IMAGE #4 -->
					  	<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-03.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-03.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 										 
										</div> 

									</div>
								</a>
							</div>
						</div>	


						<!-- IMAGE #5 -->
					  	<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-04.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-04.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
											 										 
										</div> 

									</div>
								</a>
							</div>
						</div>	


						<!-- IMAGE #6 -->
					  	<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-05.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-05.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
											 											 
										</div> 

									</div>
								</a>
							</div>
						</div>	


						<!-- IMAGE #7 -->
					  	<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-06.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-06.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 										 
										</div> 

									</div>
								</a>
							</div>
						</div>	


						<!-- IMAGE #8 -->
					  	<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-07-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-07.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>
 
						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-08-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-08.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-09-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-09.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-10-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-10.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-11-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-11.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-12-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-12.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-13-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-13.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-14-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-14.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-15-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-15.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

						<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/gallery-pic-16-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/gallery-pic-16.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
										 												 
										</div> 

									</div>
								</a>
							</div>
						</div>

 

					</div>	  <!-- End row -->
				</div>	   <!-- End container -->
			</section>	<!-- END GALLERY-2 -->

</div>	<!-- END PAGE CONTENT -->


<?php include "footer.php";?>