<?php include "header-inner.php";?>


<!-- PAGE HERO
============================================= -->	
<div id="about-page" class="page-hero-section division">
    <div class="container">	
        <div class="row">	
            <div class="col-lg-10 offset-lg-1">
                <div class="hero-txt text-center white-color">

                    <!-- Breadcrumb -->
                    <div id="breadcrumb">
                        <div class="row">						
                            <div class="col">
                                <div class="breadcrumb-nav">
                                    <nav aria-label="breadcrumb">
                                          <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Franchise</li>
                                          </ol>
                                    </nav>
                                </div>
                            </div>
                        </div> 
                    </div>

                    <!-- Title -->
                    <h2 class="h2-xl">ChiqBy Franchise</h2>

                </div>
            </div>	
        </div>	  <!-- End row -->
    </div>	   <!-- End container --> 
</div>	<!-- END PAGE HERO -->	

</header>
 
<div id="page" class="page"> 




 
<!-- ABOUT-4
============================================= -->
<section id="about-4" class="mt-65 about-section division">
    <div class="container">
        <div class="row d-flex align-items-center">

 
            <div class="col-md-6 col-lg-6">
                <div class=" mb-40">

                  
                    <h2 class="h2-sm">BOUNDLESS
                        POSSIBILITIES TO GROW
                        & MAKE YOUR MARK!</h2>   
                </div>
            </div>	 
            
            <div class="col-md-6 col-lg-6">
                <div class="  mb-40">  
                    <img class="img-fluid" src="images/chiqby-showroom.jpg" alt="Outlet">
                </div>
            </div>

            <div class="col-md-12 col-lg-12">
                <div class=" "> 
                        <p>Are you ready to embark on a finger-licking adventure that will leave your taste buds craving for more?
                            Look no further! We proudly present our exclusive franchise specializing in fried chicken. Here,
                            you'll experience the perfect combination of crispy and succulent flavours that will
                            leave you craving for more. Chiqby Foods L.L.P, is an upcoming international
                            brand with a chain of outlets selling different kinds of fried chicken,
                            rollers, strips, zingers, popcorn, nuggets sandwiches, and
                            coolers. Our primary goal is to enhance and uphold quality
                            within the fast food industry, with the aim of securing
                            a significant share of the market.</p>

                </div>
            </div>


        </div>	   <!-- End row -->
    </div>	   <!-- End container -->
</section>	<!-- END ABOUT-4 --> 


<div id="booking-2" class="wide-70 booking-section division">
    <div class="container">
         <div class="row">


            <!-- BOOKING FORM -->
             <div class="col-lg-10 col-xl-8 offset-lg-1 offset-xl-2">
                 <div class="form-holder">

                     <!-- Text -->	
                    <p class="p-xl text-center">
                        Fill in the form below or give us a call <a href="tel:123456789">00974-55564876</a>
                    </p>

                    <!-- Form -->
                    <form name="bookinkform" class="row booking-form">

                        <!-- Form Input -->
                         <div class="col-lg-6">
                            <input type="text" name="name" class="form-control name" placeholder="Your Name*" required> 
                        </div>
                                
                        <!-- Form Input -->
                        <div class="col-lg-6">
                            <input type="text" name="city" class="form-control name" placeholder="City*" required> 
                        </div>
                          
                        <!-- Form Input -->        
                        <div class="col-lg-6">
                            <input type="email" name="email" class="form-control email" placeholder="Email Address*" required> 
                        </div>

                        <!-- Form Input -->   
                        <div class="col-lg-6">
                            <input type="tel" name="phone" class="form-control phone" placeholder="Phone Number*" required> 
                        </div>

                        <!-- Form Textarea -->	        
                        <div class="col-md-12">
                            <textarea name="message" class="form-control message" rows="4" placeholder="Your Message ..."></textarea>
                        </div> 
                                                    
                        <!-- Form Button -->
                        <div class="col-md-12 mt-10">  
                            <button type="submit" class="btn btn-md btn-red tra-red-hover submit">Request Franchise</button> 
                        </div>
                                                                      
                        <!-- Form Message -->
                        <div class="col-md-12 booking-form-msg text-center">
                            <div class="sending-msg"><span class="loading"></span></div>
                        </div>	
                                                                                
                    </form>	<!-- End Form -->	

                 </div>	
             </div>	<!-- END BOOKING FORM -->	

        </div>	<!-- End row -->
    </div>	   <!-- End container -->	
</div>	<!-- END BOOKING-2 -->


	<!-- BANNER-3
			============================================= -->
			<section id="banner-3" class="bg-red banner-section division">
				<div class="container">
			 		<div class="row d-flex align-items-center">


			 			<!-- BANNER TEXT -->
						<div class="col-md-7 col-lg-6">
							<div class="banner-3-txt white-color">

								<!-- Title  -->
								<h4 class="h4-xl">Franchise</h4>
								<h2>LESS INVESTMENT
									MORE OPPORTUNITIES</h2>
								
							   <!-- Text -->	
								<p class="p-md">With a minimal investment you can launch your own Chiqby
									Foods L.L.P, unit franchise in the heart of Kerala, India.
									 
								</p>

								<!-- Store Badges -->
								<div class="stores-badge">
									<h2>00974-55564876</h2>
 
								 
									<!-- <a href="franchise.php" class="btn btn-lg btn-red tra-white-hover">Franchise Apply</a>  -->
									<a href="images/Chiqby-Franchise.pdf" target="_blank" class="btn btn-lg btn-white tra-white-hover">Download Brochure</a>	
								</div>

							</div>
						</div>


						<!-- BANNER IMAGE -->
						<div class="col-md-5 col-lg-6">
							<div class="banner-3-img">
								<img class="img-fluid" src="images/e-shop.png" alt="banner-image">
							</div>
						</div>


			 		</div>      <!-- End row -->
				</div>	    <!-- End container -->		
			</section>	<!-- END BANNER-3 -->



 

</div>	<!-- END PAGE CONTENT -->


<?php include "footer.php";?>