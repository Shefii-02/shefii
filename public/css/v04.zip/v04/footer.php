

			<!-- BANNER-4
			============================================= -->
			<section id="banner-4" class="bg-fixed pt-100 banner-section division">
				<div class="container">
			 		<div class="row">


			 			<!-- BANNER TEXT -->
						<div class="col-lg-10 col-xl-8 offset-lg-1 offset-xl-2">
							<div class="banner-4-txt text-center">

								<!-- Title  -->
								<h4 class="h4-xl">We Guarantee</h4>
								
								<!-- Title  -->
							    <h2>30 Minutes Delivery!</h2>

							    <!-- Text -->	
								<p class="p-lg">Quick, reliable, and delicious – that's the promise of our 30-Minute Delivery Fried Chicken.</p>

								<!-- Call Button -->
								<!-- <a href="tel:123456789" class="btn btn-lg btn-red tra-red-hover">Call: 974-7546-990 </a> -->

							</div>
						</div>


			 		</div>      <!-- End row -->
				</div>	    <!-- End container -->		


				<div id="promo-3" class="promo-section division">
				<div class="container">
					<div class="row d-flex align-items-center">


						<!-- PROMO IMAGE-1 -->
						<div class="col-md-4">
							<a href="menu.php">
								<div class="pbox-3 mb-30">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/offer-01.jpg" alt="promo-image">
									</div> 
								</div>
							</a>
						</div>


						<!-- PROMO IMAGE-2 -->
						<div class="col-md-4">
							<a href="menu.php">
								<div class="pbox-3 mb-30">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/offer-02.jpg" alt="promo-image">
									</div> 
								</div>
							</a>
						</div>


						<!-- PROMO IMAGE-3 -->
						<div class="col-md-4">
							<a href="menu.php">
								<div class="pbox-3 mb-30">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/offer-03.jpg" alt="promo-image">
									</div> 
								</div>
							</a>
						</div>


						<!-- PROMO IMAGE-4 -->
						<div class="col-md-4">
							<a href="menu.php">
								<div class="pbox-3 mb-30">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/offer-04.jpg" alt="promo-image">
									</div> 
								</div>
							</a>
						</div>

						<!-- PROMO IMAGE-4 -->
						<div class="col-md-4">
							<a href="menu.php">
								<div class="pbox-3 mb-30">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/offer-05.jpg" alt="promo-image">
									</div> 
								</div>
							</a>
						</div>

						<!-- PROMO IMAGE-4 -->
						<div class="col-md-4">
							<a href="menu.php">
								<div class="pbox-3 mb-30">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/offer-06.jpg" alt="promo-image">
									</div> 
								</div>
							</a>
						</div>


					</div>    <!-- End row -->		
				</div>	   <!-- End container -->	
			</div>

			</section>	<!-- END BANNER-4 -->


			


			<!-- FOOTER-2
			============================================= -->
			<footer id="footer-2" class="footer division">
				<div class="container">
					<div class="footer-2-holder text-center">
						<div class="row">

						
							<!-- FOOTER INFO -->
							<div class="col-sm-6 col-lg-3">
								<div class="footer-info mb-30">
								
									<!-- Title -->
									<h5 class="h5-md">Head Office</h5>

									<!-- Address -->
									<p>Chiqby Foods L.L.P</p>  
									<p>P.O Box 32093,</p>  
									<p>Doha-Qatar</p>
									<p>00974-55564876</p>

								</div>
							</div>


							<!-- WORKING HOURS -->
							<div class="col-sm-6 col-lg-3">
								<div class="footer-info mb-30">
								
									<!-- Title -->
									<h5 class="h5-md">Zonal Office</h5>

									<!-- Text -->
									<p>Chiqby Foods L.L.P</p>  
									<p>Pandikkad Road, Malappuram</p>  
									<p>Kerala-676 121</p>
									<p>00919747546990</p>

								</div>
							</div>


							<!-- FOOTER CONTACTS -->
							<div class="col-sm-6 col-lg-3">
								<div class="footer-contacts mb-30">
													
									<!-- Title -->
									<h5 class="h5-md">Contact Us</h5>

									<p class="mt-5"><span class="yellow-color"><a href="tel:0097455564876">00974-5556-4876</a></span></p>
									<p class="mt-5"><span class="yellow-color"><a href="tel:919747546990">91-9747-546-990</a></span></p>

									<p>FSSAI - 21323152000492</p>  
									<p>GST No - 32HGCPK2879G1ZA</p> 
									

								</div>	
							</div>


							<!-- FOOTER IMAGES -->
							<div class="col-sm-6 col-lg-3">
								<div class="footer-socials-links mb-30">

									<!-- Title -->
									<h5 class="h5-md">Follow Us</h5>

									<!-- Text -->
									<p>Click 'Follow Us' and embark on a journey of discovery and connection with our brand today.</p> 

									<!-- List -->
									<ul class="foo-socials text-center clearfix">																	
										<li><a href="#" class="ico-facebook"><i class="fab fa-facebook-f"></i></a></li> 
										<li><a href="#" class="ico-instagram"><i class="fab fa-instagram"></i></a></li>
										<li><a href="#" class="ico-youtube"><i class="fab fa-youtube"></i></a></li>
															
								 
									</ul>
															
								</div>
							</div>	<!-- END FOOTER IMAGES -->


						</div> <!-- END FOOTER CONTENT -->


						<!-- FOOTER COPYRIGHT -->
						<div class="bottom-footer">
							<div class="row d-flex align-items-center">
								<div class="col-lg-10 offset-lg-1">

									<!-- Links List --> 
									<ul class="bottom-footer-list clearfix">
										<li><p>&copy; 2023 Chiqby Foods L.L.P. All Rights Reserved</p></li> 
										<li><p><a href="#">Terms Of Use</a></p></li>	
										<li><p class="last-li"><a href="#">Privacy Policy</a></p></li>
									</ul>

								</div>
							</div>  <!-- End row -->
						</div>	<!-- END FOOTER COPYRIGHT -->


					</div>    <!-- End footer-2-holder -->    
				</div>     <!-- End container -->
			</footer>	<!-- END FOOTER-2 -->

			<a href="https://api.whatsapp.com/send?phone=97455564876&amp;text=Hello" class="whatsapp-btn" target="_blank"> </a>


		</div>	<!-- END PAGE CONTENT -->

 

		<!-- EXTERNAL SCRIPTS
		============================================= -->	
		<script src="js/jquery-3.5.1.min.js"></script>
		<!-- <script src="js/bootstrap.min.js"></script>	 -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

		<script src="js/modernizr.custom.js"></script>
		<script src="js/jquery.easing.js"></script>
		<!-- <script src="js/jquery.appear.js"></script> -->
		<script src="js/jquery.scrollto.js"></script> 
		<!-- <script src="js/jquery.flexslider.js"></script>
		<script src="js/owl.carousel.min.js"></script> -->
		<script src="js/jquery.magnific-popup.min.js"></script> 
				
		<!-- Custom Script -->		
		<script src="js/custom.js"></script>   


	</body>  
</html>	