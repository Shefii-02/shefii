<?php include "header.php";?>

		<!-- PAGE CONTENT
		============================================= -->	
		<div id="page" class="page">  

			<section id="about-2" class="bg-fixed wide-100 about-section division">
				<div class="container">
					<div class="row">


						<!-- ABOUT TEXT -->
						<div class="col-lg-10 offset-lg-1">
							<div class="about-2-txt text-center">

								<!-- Title -->
								<h2 class="h2-lg">VALUES OF CHIQBY FOODS L.L.P</h2>

								<!-- Text -->
								<p class="p-lg grey-color">We concentrate all our resources on restaurant operations since that's where we cater to
									our customers. We recognize and appreciate the contributions of every team
									member at Chiqby Foods L.L.P. We continuously enhance and modernise
									our training programs to achieve excellence. We foster an environment
									of openness, honesty, and straightforward communication in all our
									interactions. We uphold the highest standards of personal and
									professional integrity at all times. We promote and embrace new
									and creative ideas, as they are essential for our competitive
									growth. We reward outcomes rather than mere efforts.
								</p>

								<!-- Button -->
								<a href="" class="btn btn-md btn-red tra-red-hover">Explore Full Menu</a>

							</div>
						</div>	<!-- END ABOUT TEXT -->


					</div>    <!-- End row -->
				</div>	   <!-- End container -->	
			</section>

			<!-- MENU-8
			============================================= -->
			<section id="menu-8" class="wide-70 menu-section division">
				<div class="container">
					<div class="row">
 
<!-- MENU ITEM #1 -->
<div class="col-sm-6 col-lg-4">
	<div class="menu-7-item">

		<!-- IMAGE -->
		<div class="menu-7-img rel"> 
			<!-- Image -->
			<img class="img-fluid" src="images/menu-item-01.jpg" alt="Fried Chicken" /> 
			<div class="menu-7-txt rel"> 
				<!-- Title -->
				<h5 class="h5-sm">Fried Chicken</h5>  
			</div>
		</div> 
		<!-- TEXT -->
		

	</div>
</div>	<!-- END MENU ITEM #1 -->
<!-- MENU ITEM #1 -->
<div class="col-sm-6 col-lg-4">
	<div class="menu-7-item">

		<!-- IMAGE -->
		<div class="menu-7-img rel"> 
			<!-- Image -->
			<img class="img-fluid" src="images/menu-item-02.jpg" alt="Burger" /> 
			<div class="menu-7-txt rel"> 
				<!-- Title -->
				<h5 class="h5-sm">Burger</h5>  
			</div>
		</div> 
		<!-- TEXT -->
		

	</div>
</div>	<!-- END MENU ITEM #1 -->
<!-- MENU ITEM #1 -->
<div class="col-sm-6 col-lg-4">
	<div class="menu-7-item">

		<!-- IMAGE -->
		<div class="menu-7-img rel"> 
			<!-- Image -->
			<img class="img-fluid" src="images/menu-item-03.jpg" alt="Chicken Nuggets" /> 
			<div class="menu-7-txt rel"> 
				<!-- Title -->
				<h5 class="h5-sm">Chicken Nuggets</h5>  
			</div>
		</div> 
		<!-- TEXT -->
		

	</div>
</div>	<!-- END MENU ITEM #1 -->
<!-- MENU ITEM #1 -->
<div class="col-sm-6 col-lg-4">
	<div class="menu-7-item">

		<!-- IMAGE -->
		<div class="menu-7-img rel"> 
			<!-- Image -->
			<img class="img-fluid" src="images/menu-item-04.jpg" alt="Chicken Strips" /> 
			<div class="menu-7-txt rel"> 
				<!-- Title -->
				<h5 class="h5-sm">Chicken Strips</h5>  
			</div>
		</div> 
		<!-- TEXT -->
		

	</div>
</div>	<!-- END MENU ITEM #1 -->
<!-- MENU ITEM #1 -->
<div class="col-sm-6 col-lg-4">
	<div class="menu-7-item">

		<!-- IMAGE -->
		<div class="menu-7-img rel"> 
			<!-- Image -->
			<img class="img-fluid" src="images/menu-item-05.jpg" alt="Popcon" /> 
			<div class="menu-7-txt rel"> 
				<!-- Title -->
				<h5 class="h5-sm">Chicken Pops</h5>  
			</div>
		</div> 
		<!-- TEXT -->
		

	</div>
</div>	<!-- END MENU ITEM #1 -->
<!-- MENU ITEM #1 -->
<div class="col-sm-6 col-lg-4">
	<div class="menu-7-item">

		<!-- IMAGE -->
		<div class="menu-7-img rel"> 
			<!-- Image -->
			<img class="img-fluid" src="images/menu-item-06.jpg" alt="Mojito" /> 
			<div class="menu-7-txt rel"> 
				<!-- Title -->
				<h5 class="h5-sm">Mojito</h5>  
			</div>
		</div> 
		<!-- TEXT -->
		

	</div>
</div>	<!-- END MENU ITEM #1 -->

</div>	

				</div>	   <!-- End container -->
			</section>	<!-- END MENU-8 -->




			<!-- PROMO-11
			============================================= -->
			<section id="promo-11" class="bg-fixed promo-section division">
				<div class="container">
					<div class="row d-flex align-items-center">


						<!-- PROMO TEXT -->
						<div class="col-md-5 col-lg-4">
							<div class="pbox-11-txt mb-40 white-color">

								<!-- Title -->
								<h3 class="h3-lg">The</h3>
								<h2>Real & Juicy</h2>

								<!-- Text -->
								<p class="p-md">Come & taste our freshly cooked, delicious fried chicken by an international brand.</p>

								<!-- Button -->
								<a href="" class="btn btn-lg btn-white tra-white-hover">Know More</a>

							</div>
						</div>


						<!-- PROMO IMAGE -->
						<div class="col-md-7 col-lg-8">
							<div class="pbox-11-img mb-40">

								<!-- Image -->	
								<img class="img-fluid" src="images/promo-11-img.png" alt="promo-image" />

								<!-- Price Badge -->
								<div class="red-badge price-badge-lg bg-fixed">
									<div class="badge-txt white-color">
										<h5 class="h5-xl">Fresh</h5>
										<h3 class="h3-sm">Spicy</h3> 
									</div>
								</div>

							</div>
						</div>


						<!-- PROMO LINKS -->
						<!-- <div class="col-lg-2">

						 
							<div class="pbox-11-link text-center white-color">
								<a href="product-single.html">
									<img class="img-fluid" src="images/menu/burger-02.png" alt="promo-image" />
									<p>Ultimate Bacon Burger</p>
								</a>
							</div>

						 
							<div class="pbox-11-link text-center mb-40 white-color">
								<a href="product-single.html">
									<img class="img-fluid" src="images/menu/burger-05.png" alt="promo-image" />
									<p>Grilled Chicken Burger</p>
								</a>
							</div>

						</div> -->


					</div>    <!-- End row -->		
				</div>	   <!-- End container -->	
			</section>	<!-- END PROMO-11 -->
 

		 
			<!-- ABOUT-3
			============================================= -->
			<section id="about-3" class="wide-60 about-section division">
				<div class="container">
					<div class="row d-flex align-items-center">


						<!-- ABOUT IMAGE -->
						<div class="col-md-5 col-lg-6">
							<div class="about-3-img text-center mb-40">
								<img class="img-fluid" src="images/about-01-img.png" alt="about-image">
							</div>
						</div>


						<!-- ABOUT TEXT -->
						<div class="col-md-7 col-lg-6">
							<div class="about-3-txt mb-40">

								<!-- Title -->	
								<h2 class="h2-sm">Nothing unites people quite like a delicious Good Fried Chicken</h2>

								<!-- Text -->
								<p class="p-md">Few things possess the magical ability to bring people together as effectively as a perfectly cooked batch of fried chicken. The crispy, golden exterior and succulent, flavorful meat have an uncanny way of fostering a sense of unity, where friends and family gather to savor the shared delight of this beloved dish.</p>
								<p class="p-md">Whether enjoyed at a picnic, a family reunion, or a casual dinner, the simple joy of good fried chicken transcends cultural and culinary boundaries, creating cherished memories and fostering a sense of togetherness like few other foods can. 
								</p> 

								<a href="" class="btn btn-lg btn-red tra-red-hover">Know More</a>

							</div>
						</div>	<!-- END ABOUT TEXT -->	


					</div>	   <!-- End row -->
				</div>	   <!-- End container -->
			</section>	<!-- END ABOUT-3 -->

 

			<!-- BANNER-3
			============================================= -->
			<section id="banner-3" class="bg-red banner-section division">
				<div class="container">
			 		<div class="row d-flex align-items-center">


			 			<!-- BANNER TEXT -->
						<div class="col-md-7 col-lg-6">
							<div class="banner-3-txt white-color">

								<!-- Title  -->
								<h4 class="h4-xl">Franchise</h4>
								<h2>LESS INVESTMENT
									MORE OPPORTUNITIES</h2>
								
							   <!-- Text -->	
								<p class="p-md">With a minimal investment you can launch your own Chiqby
									Foods L.L.P, unit franchise in the heart of Kerala, India.
									 
								</p>

								<!-- Store Badges -->
								<div class="stores-badge">
									<h2>00974-55564876</h2>
 
									<!-- <a href="#" class="store">
										<img class="appstore-original" src="images/appstore.png" alt="appstore-logo" />
									</a>
													 
									<a href="#" class="store">
										<img class="googleplay-original" src="images/googleplay.png" alt="googleplay-logo" />
									</a> -->
									<a href="franchise.php" class="btn btn-lg btn-white tra-white-hover">Franchise Apply</a> 
									<a href="images/Chiqby-Franchise.pdf" target="_blank" class="btn btn-lg btn-white tra-white-hover">Download Brochure</a>	
								</div>

							</div>
						</div>


						<!-- BANNER IMAGE -->
						<div class="col-md-5 col-lg-6">
							<div class="banner-3-img">
								<img class="img-fluid" src="images/e-shop.png" alt="banner-image">
							</div>
						</div>


			 		</div>      <!-- End row -->
				</div>	    <!-- End container -->		
			</section>	<!-- END BANNER-3 -->



 


			<!-- GALLERY-2
			============================================= -->		
			<section id="gallery-2" class="gallery-section division">
				<div class="container">

 
					<!-- IMAGES HOLDER -->
					<div class="row">

 
					  	<div class="col-sm-6 col-lg-3">
					  		<div class="gallery-img">
						  		<a href="images/gallery/ISO-9001-2015-xl.jpg" class="image-link">
									<div class="hover-overlay"> 
										<img class="img-fluid" src="images/gallery/ISO-9001-2015.jpg" alt="gallery-image" />			
										<div class="item-overlay"></div>

										<!-- Image Meta -->
										<div class="img-meta white-color">
											<h5 class="h5-xs">Description</h5>		
											<div class="txt-block-rating">
												<div class="stars-rating">
													<span>4.5</span>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star-half-alt"></i>
													<span>(23)</span>
												</div>		
											</div>										 
										</div> 

									</div>
								</a>
							</div>
						</div>
						<div class="col-sm-6 col-lg-3">
							<div class="gallery-img">
								<a href="images/gallery/gallery-pic-02.jpg" class="image-link">
								  <div class="hover-overlay"> 
									  <img class="img-fluid" src="images/gallery/gallery-pic-02.jpg" alt="gallery-image" />			
									  <div class="item-overlay"></div>

									  <!-- Image Meta -->
									  <div class="img-meta white-color">
										  <h5 class="h5-xs">Description</h5>		
										  <div class="txt-block-rating">
											  <div class="stars-rating">
												  <span>4.5</span>
												  <i class="fas fa-star"></i>
												  <i class="fas fa-star"></i>
												  <i class="fas fa-star"></i>
												  <i class="fas fa-star"></i>
												  <i class="fas fa-star-half-alt"></i>
												  <span>(23)</span>
											  </div>		
										  </div>										 
									  </div> 

								  </div>
							  </a>
						  </div>
					  </div>
					  <div class="col-sm-6 col-lg-3">
						<div class="gallery-img">
							<a href="images/gallery/gallery-pic-03.jpg" class="image-link">
							  <div class="hover-overlay"> 
								  <img class="img-fluid" src="images/gallery/gallery-pic-03.jpg" alt="gallery-image" />			
								  <div class="item-overlay"></div>

								  <!-- Image Meta -->
								  <div class="img-meta white-color">
									  <h5 class="h5-xs">Description</h5>		
									  <div class="txt-block-rating">
										  <div class="stars-rating">
											  <span>4.5</span>
											  <i class="fas fa-star"></i>
											  <i class="fas fa-star"></i>
											  <i class="fas fa-star"></i>
											  <i class="fas fa-star"></i>
											  <i class="fas fa-star-half-alt"></i>
											  <span>(23)</span>
										  </div>		
									  </div>										 
								  </div> 

							  </div>
						  </a>
					  </div>
				  </div>
				  <div class="col-sm-6 col-lg-3">
					<div class="gallery-img">
						<a href="images/gallery/gallery-pic-04.jpg" class="image-link">
						  <div class="hover-overlay"> 
							  <img class="img-fluid" src="images/gallery/gallery-pic-04.jpg" alt="gallery-image" />			
							  <div class="item-overlay"></div>

							  <!-- Image Meta -->
							  <div class="img-meta white-color">
								  <h5 class="h5-xs">Description</h5>		
								  <div class="txt-block-rating">
									  <div class="stars-rating">
										  <span>4.5</span>
										  <i class="fas fa-star"></i>
										  <i class="fas fa-star"></i>
										  <i class="fas fa-star"></i>
										  <i class="fas fa-star"></i>
										  <i class="fas fa-star-half-alt"></i>
										  <span>(23)</span>
									  </div>		
								  </div>										 
							  </div> 

						  </div>
					  </a>
				  </div>
			  </div>
			  <div class="col-sm-6 col-lg-3">
				<div class="gallery-img">
					<a href="images/gallery/gallery-pic-05.jpg" class="image-link">
					  <div class="hover-overlay"> 
						  <img class="img-fluid" src="images/gallery/gallery-pic-05.jpg" alt="gallery-image" />			
						  <div class="item-overlay"></div>

						  <!-- Image Meta -->
						  <div class="img-meta white-color">
							  <h5 class="h5-xs">Description</h5>		
							  <div class="txt-block-rating">
								  <div class="stars-rating">
									  <span>4.5</span>
									  <i class="fas fa-star"></i>
									  <i class="fas fa-star"></i>
									  <i class="fas fa-star"></i>
									  <i class="fas fa-star"></i>
									  <i class="fas fa-star-half-alt"></i>
									  <span>(23)</span>
								  </div>		
							  </div>										 
						  </div> 

					  </div>
				  </a>
			  </div>
		  </div>
		  <div class="col-sm-6 col-lg-3">
			<div class="gallery-img">
				<a href="images/gallery/gallery-pic-06.jpg" class="image-link">
				  <div class="hover-overlay"> 
					  <img class="img-fluid" src="images/gallery/gallery-pic-06.jpg" alt="gallery-image" />			
					  <div class="item-overlay"></div>

					  <!-- Image Meta -->
					  <div class="img-meta white-color">
						  <h5 class="h5-xs">Description</h5>		
						  <div class="txt-block-rating">
							  <div class="stars-rating">
								  <span>4.5</span>
								  <i class="fas fa-star"></i>
								  <i class="fas fa-star"></i>
								  <i class="fas fa-star"></i>
								  <i class="fas fa-star"></i>
								  <i class="fas fa-star-half-alt"></i>
								  <span>(23)</span>
							  </div>		
						  </div>										 
					  </div> 

				  </div>
			  </a>
		  </div>
	  </div>
	  <div class="col-sm-6 col-lg-3">
		<div class="gallery-img">
			<a href="images/gallery/gallery-pic-07-xl.jpg" class="image-link">
			  <div class="hover-overlay"> 
				  <img class="img-fluid" src="images/gallery/gallery-pic-07.jpg" alt="gallery-image" />			
				  <div class="item-overlay"></div>

				  <!-- Image Meta -->
				  <div class="img-meta white-color">
					  <h5 class="h5-xs">Description</h5>		
					  <div class="txt-block-rating">
						  <div class="stars-rating">
							  <span>4.5</span>
							  <i class="fas fa-star"></i>
							  <i class="fas fa-star"></i>
							  <i class="fas fa-star"></i>
							  <i class="fas fa-star"></i>
							  <i class="fas fa-star-half-alt"></i>
							  <span>(23)</span>
						  </div>		
					  </div>										 
				  </div> 

			  </div>
		  </a>
	  </div>
  </div>
  <div class="col-sm-6 col-lg-3">
	<div class="gallery-img">
		<a href="images/gallery/gallery-pic-08-xl.jpg" class="image-link">
		  <div class="hover-overlay"> 
			  <img class="img-fluid" src="images/gallery/gallery-pic-08.jpg" alt="gallery-image" />			
			  <div class="item-overlay"></div>

			  <!-- Image Meta -->
			  <div class="img-meta white-color">
				  <h5 class="h5-xs">Description</h5>		
				  <div class="txt-block-rating">
					  <div class="stars-rating">
						  <span>4.5</span>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star-half-alt"></i>
						  <span>(23)</span>
					  </div>		
				  </div>										 
			  </div> 

		  </div>
	  </a>
  </div>
</div>

 


					</div>	<!-- END IMAGES HOLDER -->


				</div>	   <!-- End container -->
			</section>	<!-- END GALLERY-2 -->


<?php include "footer.php";?>